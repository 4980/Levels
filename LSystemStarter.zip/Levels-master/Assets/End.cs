﻿using System.Collections.Generic;

public class End
{
    public float Strength;
    public List<string> values = new List<string>();
}