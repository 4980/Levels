﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BadBullet : MonoBehaviour {

    float TimeAlive = 0;
    public GameObject BadBulletDeath;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {

        TimeAlive += Time.deltaTime;

        if (TimeAlive > 5)
        {
            Instantiate(BadBulletDeath, transform.position, Quaternion.identity);
            Destroy(this.gameObject);
        }

    }



    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == GameState.Shooter.tag)
        {
            GameState.Shooter.takeDamage();
        }

        GameObject particles = Instantiate<GameObject>(BadBulletDeath, transform.position, Quaternion.identity);
        Destroy(particles, 1);
        Destroy(this.gameObject);
    }
}
