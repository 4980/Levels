﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.Characters.FirstPerson;

public class Shooter : MonoBehaviour {

	public Bullet Bullet;
    public Camera myCamera;

    const float MinTimeBetweenShots = 2.0f;
    float TimeSinceLastShot = MinTimeBetweenShots;
    public float shield = 0f;
    public float heat = 0f;
    public bool inGame = false;
    public bool invincible = false;
    public float damageMultiplier = 1.0f;
    public float shieldRecoveryMultiplier = 1.0f;


    // Use this for initialization
    void Start()
    {
    }
	
	// Update is called once per frame
	void FixedUpdate () {

        shield += Time.deltaTime * shieldRecoveryMultiplier;

        shield = Math.Min(1, shield);

        


        TimeSinceLastShot += Time.deltaTime;

        if(Input.GetMouseButtonDown(0) && Bullet != null)
        {
            TimeSinceLastShot = 0;
            Bullet bullet = Instantiate<Bullet>(Bullet, transform.position + transform.up / 2 + transform.right / 2 + transform.forward * 2, Quaternion.identity);
            bullet.GetComponent<Rigidbody>().velocity = myCamera.transform.forward * 50;

            Debug.Log(Camera.main.transform.forward);
        }
		
	}

    internal void Boot()
    {
        inGame = true;
        heat = 0;
        shield = 1;
    }

    public void takeDamage()
    {
        if (invincible)
            return;
        shield -= damageMultiplier;

        if(shield <= 0)
        {
            shield = 0;
            GameState.DieTransition();
        }
    }
}
