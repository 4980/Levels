﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleEnemyScript : MonoBehaviour {

    public GameObject DeathParticles;
    private bool trackingPlayer = false;
    float timeSinceLastBullet;
    const float timeBetweenShots = 2.0f;
    public GameObject BadBullet;
    public float Health = 1;

	// Use this for initialization
	void Start () {
        Reboot();
		
	}
	
	// Update is called once per frame
	void Update () {
        if (GameState.GAME_STATE == GameState.GAME_ON)
        {
            if (trackingPlayer)
            {
                Quaternion perfectLook = Quaternion.LookRotation(GameState.Shooter.transform.position - transform.position, Vector3.up);
                transform.rotation = Quaternion.Lerp(transform.rotation, perfectLook, Time.deltaTime);


                if (timeSinceLastBullet > timeBetweenShots)
                {
                    timeSinceLastBullet = 0;
                    GameObject badBullet = Instantiate<GameObject>(BadBullet, transform.position + transform.forward, Quaternion.identity);
                    badBullet.GetComponent<Rigidbody>().velocity = transform.forward * 10;
                }

            }

            timeSinceLastBullet += Time.deltaTime;
        }
        else
        {
            Reboot();
        }
		
	}

    void Reboot()
    {
        trackingPlayer = false;
        timeSinceLastBullet = float.PositiveInfinity;
        Health = 1;

    }

    void OnTriggerEnter(Collider other)
    {
        if (GameState.Shooter!= null && other.gameObject.tag == GameState.Shooter.tag)
        {
            Debug.Log("Collider enter");
            trackingPlayer = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (GameState.Shooter != null && other.gameObject.tag == GameState.Shooter.tag)
        {
            Debug.Log("Collider exit");
            trackingPlayer = false;
        }
    }

    public void takeDamage()
    {
        Health -= .5f;

        if (Health <= 0)
        {
            Instantiate(DeathParticles, transform.position, Quaternion.identity);
            Destroy(this.gameObject);
        }

    }
}
