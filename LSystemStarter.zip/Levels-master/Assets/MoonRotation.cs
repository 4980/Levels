﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoonRotation : MonoBehaviour {

    public float rX = 0;
    public float rY = 0;
    public float rZ = 0;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        transform.localRotation = Quaternion.Euler(Time.time * rX, Time.time * rY, Time.time * rZ);
		
	}
}
